import time
import pandas as pd
import requests

from .models import Automacao
from provedor.models import Provedor


# ========= COLE SUAS CHAVES AQUI =========
GOOGLE_API_KEY = "COLE_SUA_API_KEY_AQUI"
GOOGLE_CSE_ID  = "COLE_SEU_CX_AQUI"
# ========================================


def _buscar_primeiro_link_cse(query: str) -> str | None:
    if not GOOGLE_API_KEY or not GOOGLE_CSE_ID or "COLE_" in GOOGLE_API_KEY or "COLE_" in GOOGLE_CSE_ID:
        raise Exception(
            "Você precisa preencher GOOGLE_API_KEY e GOOGLE_CSE_ID (cx) no arquivo da automação."
        )

    url = "https://www.googleapis.com/customsearch/v1"
    params = {
        "key": GOOGLE_API_KEY,
        "cx": GOOGLE_CSE_ID,
        "q": query,
        "num": 5,
        "hl": "pt",
        "gl": "br",
    }

    r = requests.get(url, params=params, timeout=20)

    if r.status_code != 200:
        # Evita printar a key. Mostra só o erro da API.
        try:
            msg = r.json()
        except Exception:
            msg = r.text
        raise Exception(f"Erro na API do Google (HTTP {r.status_code}): {msg}")

    data = r.json()
    items = data.get("items") or []

    blacklist = (
        "facebook.com",
        "instagram.com",
        "linkedin.com",
        "wikipedia.org",
        "youtube.com",
        "twitter.com",
        "x.com",
    )

    for item in items:
        link = item.get("link")
        if not link:
            continue
        if any(dom in link for dom in blacklist):
            continue
        return link

    return None


def automacao_google_provedores(tarefa_id, file_path):
    try:
        df = pd.read_excel(file_path)
        tarefa = Automacao.objects.get(id=tarefa_id)

        for _, row in df.iterrows():
            tarefa.refresh_from_db()
            if tarefa.status != "executando":
                break

            nome_pesquisa = str(row.get("nome", "")).strip()
            if not nome_pesquisa or nome_pesquisa.lower() == "nan":
                continue

            print(f"Pesquisando: {nome_pesquisa}")

            # Evita gastar requisição se já existe com url preenchida
            existente = Provedor.objects.filter(nome=nome_pesquisa).first()
            if existente and getattr(existente, "url_site", None):
                print(f"Já existe com URL: {nome_pesquisa} -> {existente.url_site}")
                continue

            query = f"provedor de internet {nome_pesquisa} site oficial"

            try:
                primeiro_link = _buscar_primeiro_link_cse(query)
            except Exception as e:
                print(f"Falhou busca '{nome_pesquisa}': {e}")
                time.sleep(0.7)
                continue

            if not primeiro_link:
                print(f"Sem resultado para: {nome_pesquisa}")
                time.sleep(0.4)
                continue

            cidade = row.get("cidade", "Itaitinga")
            estado = row.get("estado", "CE")

            prov, created = Provedor.objects.get_or_create(
                nome=nome_pesquisa,
                defaults={
                    "url_site": primeiro_link,
                    "cidade": cidade if pd.notna(cidade) else "Itaitinga",
                    "estado": estado if pd.notna(estado) else "CE",
                },
            )

            # se já existia mas sem url, atualiza
            if not created and (not getattr(prov, "url_site", None)):
                prov.url_site = primeiro_link
                if hasattr(prov, "cidade") and (not getattr(prov, "cidade", None)):
                    prov.cidade = cidade if pd.notna(cidade) else "Itaitinga"
                if hasattr(prov, "estado") and (not getattr(prov, "estado", None)):
                    prov.estado = estado if pd.notna(estado) else "CE"
                prov.save(update_fields=["url_site", "cidade", "estado"])

            print(f"Sucesso: {nome_pesquisa} -> {primeiro_link}")
            time.sleep(0.8)

        tarefa.refresh_from_db()
        if tarefa.status == "executando":
            tarefa.status = "concluido"
            tarefa.save()

    except Exception as e:
        print(f"Erro geral: {e}")
        tarefa = Automacao.objects.get(id=tarefa_id)
        tarefa.status = "falha"
        tarefa.save()


REGISTRY = {
    "busca_google_provedores": automacao_google_provedores,
}